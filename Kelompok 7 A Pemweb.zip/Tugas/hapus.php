<?php
include "koneksi.php";

$nik = $_GET['nik'];
mysqli_query($koneksi, "DELETE FROM daftar_buku_tamu WHERE nik='$nik'");

echo "<script>alert('Data dihapus');window.location='index.php';</script>";
?>
