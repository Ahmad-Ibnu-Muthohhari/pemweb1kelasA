<?php
$koneksi = mysqli_connect("localhost", "root", "", "tugas_uas");

if(!$koneksi){
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
