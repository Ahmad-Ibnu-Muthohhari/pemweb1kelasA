<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Buku Tamu</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h2 class="text-center mb-4">📘 Daftar Buku Tamu</h2>

    <a href="tambah.php" class="btn btn-primary mb-3">+ Tambah Data</a>

    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>NIK</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Pesan</th>
                <th>Tanggal</th>
                <th>No Telepon</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $data = mysqli_query($koneksi, "SELECT * FROM daftar_buku_tamu");
            while($row = mysqli_fetch_array($data)){ ?>
            <tr>
                <td><?= $row['nik']; ?></td>
                <td><?= $row['nama']; ?></td>
                <td><?= $row['email']; ?></td>
                <td><?= $row['pesan']; ?></td>
                <td><?= $row['tanggal']; ?></td>
                <td><?= $row['nomor_telepon']; ?></td>
                <td>
                    <a href="edit.php?nik=<?= $row['nik']; ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a onclick="return confirm('Yakin hapus?')" href="hapus.php?nik=<?= $row['nik']; ?>" class="btn btn-sm btn-danger">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
