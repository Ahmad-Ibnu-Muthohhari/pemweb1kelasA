<?php
include "koneksi.php";
$nik = $_GET['nik'];
$data = mysqli_query($koneksi, "SELECT * FROM daftar_buku_tamu WHERE nik='$nik'");
$row = mysqli_fetch_array($data);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body class="bg-light">
<div class="container mt-4">

<h2 class="text-center mb-4">Edit Data</h2>

<div class="card shadow">
    <div class="card-body">

<form action="" method="post" enctype="multipart/form-data">

    <input type="hidden" name="nik" value="<?= $row['nik']; ?>">

    <div class="mb-3">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control" value="<?= $row['nama']; ?>">
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" value="<?= $row['email']; ?>">
    </div>

    <div class="mb-3">
        <label>Pesan</label>
        <input type="text" name="pesan" class="form-control" value="<?= $row['pesan']; ?>">
    </div>

    <div class="mb-3">
        <label>Tanggal</label>
        <input type="datetime-local" name="tanggal" class="form-control" 
        value="<?= date('Y-m-d\TH:i', strtotime($row['tanggal'])); ?>">
    </div>

    <div class="mb-3">
        <label>Nomor Telepon</label>
        <input type="number" name="nomor_telepon" class="form-control" value="<?= $row['nomor_telepon']; ?>">
    </div>

    <div class="mb-3">
        <label>Alamat</label>
        <input type="text" name="alamat" class="form-control" value="<?= $row['alamat']; ?>">
    </div>

    <div class="mb-3">
        <label>Foto Lama</label><br>
        <img src="upload/<?= $row['foto']; ?>" width="100" class="mb-2">
        <input type="file" name="foto" class="form-control">
    </div>

    <button type="submit" name="update" class="btn btn-warning">Update</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>

</form>

<?php
if(isset($_POST['update'])){

    if($_FILES['foto']['name'] != "") {
        $foto = $_FILES['foto']['name'];
        $tmp = $_FILES['foto']['tmp_name'];
        move_uploaded_file($tmp, "upload/".$foto);
    } else {
        $foto = $row['foto'];
    }

    mysqli_query($koneksi, "UPDATE daftar_buku_tamu SET
        nama='$_POST[nama]',
        email='$_POST[email]',
        pesan='$_POST[pesan]',
        tanggal='$_POST[tanggal]',
        nomor_telepon='$_POST[nomor_telepon]',
        alamat='$_POST[alamat]',
        foto='$foto'
        WHERE nik='$_POST[nik]'
    ");

    echo "<script>alert('Data diperbarui');window.location='index.php';</script>";
}
?>

</div>
</div>

</div>
</body>
</html>
