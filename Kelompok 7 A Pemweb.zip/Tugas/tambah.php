<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body class="bg-light">
<div class="container mt-4">

<h2 class="text-center mb-4">Tambah Buku Tamu</h2>

<div class="card shadow">
    <div class="card-body">

<form action="" method="post">

    <div class="mb-3">
        <label>NIK</label>
        <input type="number" name="nik" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Pesan</label>
        <input type="text" name="pesan" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Tanggal</label>
        <input type="datetime-local" name="tanggal" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Nomor Telepon</label>
        <input type="number" name="nomor_telepon" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Alamat</label>
        <input type="text" name="alamat" class="form-control" required>
    </div>

    <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>

</form>

    </div>
</div>

</div>

<?php
if(isset($_POST['simpan'])){
    mysqli_query($koneksi, "INSERT INTO daftar_buku_tamu 
    (nik, nama, email, pesan, tanggal, nomor_telepon, alamat) VALUES(
        '$_POST[nik]',
        '$_POST[nama]',
        '$_POST[email]',
        '$_POST[pesan]',
        '$_POST[tanggal]',
        '$_POST[nomor_telepon]',
        '$_POST[alamat]'
    )");

    echo "<script>alert('Data disimpan');window.location='index.php';</script>";
}
?>

</body>
</html>
